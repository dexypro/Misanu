package MVC;

import java.util.ArrayList;
import java.util.List;

public class ProizvodController {
	private List<Proizvod> proizvodi;
	private ProizvodView view;

	public ProizvodController(ProizvodView view) {
		this.proizvodi = new ArrayList<>();
		this.view = view;
	}

	public void dodajProizvod(int id, String ime, double cena) {
		Proizvod proizvod = new Proizvod(id, ime, cena);
		proizvodi.add(proizvod);
	}

	public Proizvod pronadjiProizvod(int id) {
		for (Proizvod proizvod : proizvodi) {
			if (proizvod.getId() == id) {
				return proizvod;
			}
		}
		return null;
	}

	public void azurirajProizvod(int id, String ime, double cena) {
		Proizvod proizvod = pronadjiProizvod(id);
		if (proizvod != null) {
			proizvod.setIme(ime);
			proizvod.setCena(cena);
		}
	}

	public void obrisiProizvod(int id) {
		Proizvod proizvod = pronadjiProizvod(id);
		if (proizvod != null) {
			proizvodi.remove(proizvod);
		}
	}

	public void prikaziProizvod(int id) {
		Proizvod proizvod = pronadjiProizvod(id);
		if (proizvod != null) {
			view.prikaziProizvod(proizvod);
		} else {
			System.out.println("Proizvod sa ID " + id + " nije pronađen.");
		}
	}

	public void prikaziSveProizvode() {
		view.prikaziProizvode(proizvodi);
	}

}
