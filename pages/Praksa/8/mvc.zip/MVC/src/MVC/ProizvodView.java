package MVC;

import java.util.List;

public class ProizvodView {
	public void prikaziProizvod(Proizvod proizvod) {
		System.out.println("Proizvod:");
		System.out.println("ID: " + proizvod.getId());
		System.out.println("Ime: " + proizvod.getIme());
		System.out.println("Cena: " + proizvod.getCena());
	}

	public void prikaziProizvode(List<Proizvod> proizvodi) {
		System.out.println("\nProizvodi:");
		for (Proizvod proizvod : proizvodi) {
			prikaziProizvod(proizvod);
			System.out.println();
		}
	}
}
