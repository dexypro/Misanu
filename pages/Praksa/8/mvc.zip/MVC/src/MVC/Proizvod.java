package MVC;

public class Proizvod {
	private int id;
	private String ime;
	private double cena;

	public Proizvod(int id, String ime, double cena) {
		this.id = id;
		this.ime = ime;
		this.cena = cena;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public double getCena() {
		return cena;
	}

	public void setCena(double cena) {
		this.cena = cena;
	}
}
