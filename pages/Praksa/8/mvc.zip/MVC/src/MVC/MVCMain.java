package MVC;

public class MVCMain {
	public static void main(String[] args) {
		// Kreiranje view-a
		ProizvodView view = new ProizvodView();

		// Kreiranje controller-a
		ProizvodController controller = new ProizvodController(view);

		// Dodavanje proizvoda
		controller.dodajProizvod(1, "Televizor", 500);
		controller.dodajProizvod(2, "Laptop", 1000);
		controller.dodajProizvod(3, "Mobilni telefon", 800);

		// Prikaz svih proizvoda
		controller.prikaziSveProizvode();

		// Ažuriranje proizvoda
		controller.azurirajProizvod(2, "Gaming Laptop", 1200);

		// Prikaz ažuriranog proizvoda
		controller.prikaziProizvod(2);

		// Brisanje proizvoda
		controller.obrisiProizvod(1);

		// Prikaz svih proizvoda nakon brisanja
		controller.prikaziSveProizvode();
	}
}
