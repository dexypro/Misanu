package mergeSort;

public class MergeSort {

	// Metoda za spajanje dva podniza
	public static void merge(int[] arr, int levo, int sredina, int desno) {
		// Određivanje dužina podnizova
		int n1 = sredina - levo + 1;
		int n2 = desno - sredina;

		// Pravljenje privremenih nizova
		int[] leviNiz = new int[n1];
		int[] desniNiz = new int[n2];

		// Kopiranje podataka u privremene nizove
		for (int i = 0; i < n1; i++) {
			leviNiz[i] = arr[levo + i];
		}
		for (int j = 0; j < n2; j++) {
			desniNiz[j] = arr[sredina + 1 + j];
		}

		// Spajanje privremenih nizova

		// Inicijalni indeksi prvog i drugog podniza
		int i = 0, j = 0;

		// Inicijalni indeks spajanja podnizova
		int k = levo;
		while (i < n1 && j < n2) {
			if (leviNiz[i] <= desniNiz[j]) {
				arr[k] = leviNiz[i];
				i++;
			} else {
				arr[k] = desniNiz[j];
				j++;
			}
			k++;
		}

		// Kopiranje preostalih elemenata leviNiz[], ako ih ima
		while (i < n1) {
			arr[k] = leviNiz[i];
			i++;
			k++;
		}

		// Kopiranje preostalih elemenata desniNiz[], ako ih ima
		while (j < n2) {
			arr[k] = desniNiz[j];
			j++;
			k++;
		}
	}

	// Glavna metoda koja sortira niz
	public static void mergeSort(int[] arr, int levo, int desno) {
		if (levo < desno) {
			// Pronalazak sredine niza
			int sredina = (levo + desno) / 2;

			// Sortiranje obe polovine
			mergeSort(arr, levo, sredina);
			mergeSort(arr, sredina + 1, desno);

			// Spajanje sortiranih polovina
			merge(arr, levo, sredina, desno);
		}
	}

	public static void main(String[] args) {
		int[] arr = { 12, 11, 13, 5, 6, 7 };
		System.out.println("Nesortiran niz:");
		for (int e : arr) {
			System.out.print(e + " ");
		}
		System.out.println();

		mergeSort(arr, 0, arr.length - 1);

		System.out.println("Sortiran niz:");
		for (int e : arr) {
			System.out.print(e + " ");
		}
		System.out.println();
	}
}
