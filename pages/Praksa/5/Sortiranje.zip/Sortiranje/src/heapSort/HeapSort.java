package heapSort;

public class HeapSort {
	public static void main(String[] args) {
		int[] niz = { 12, 11, 13, 5, 6, 7 };
		int duzina = niz.length;

		HeapSort heapSort = new HeapSort();
		heapSort.sortiraj(niz);

		System.out.println("Sortirani niz:");
		for (int i = 0; i < duzina; ++i) {
			System.out.print(niz[i] + " ");
		}
	}

	public void sortiraj(int niz[]) {
		int duzina = niz.length;

		// Izgradnja heap-a (reorganizacija niza)
		for (int i = duzina / 2 - 1; i >= 0; i--) {
			stvoriHeap(niz, duzina, i);
		}

		// Zamena elemenata i ponovna izgradnja heap-a
		for (int i = duzina - 1; i > 0; i--) {
			// Zamena trenutnog korena sa krajnjim elementom
			int temp = niz[0];
			niz[0] = niz[i];
			niz[i] = temp;

			// Ponovna izgradnja heap-a za preostali niz
			stvoriHeap(niz, i, 0);
		}
	}

	// Funkcija za izgradnju heap-a
	void stvoriHeap(int niz[], int duzina, int i) {
		int najveci = i; // Inicijalizacija najvećeg elementa kao korena
		int levoDete = 2 * i + 1;
		int desnoDete = 2 * i + 2;

		// Ako je levo dete veće od korena
		if (levoDete < duzina && niz[levoDete] > niz[najveci]) {
			najveci = levoDete;
		}

		// Ako je desno dete veće od trenutno najvećeg elementa
		if (desnoDete < duzina && niz[desnoDete] > niz[najveci]) {
			najveci = desnoDete;
		}

		// Ako najveci element nije koren
		if (najveci != i) {
			int temp = niz[i];
			niz[i] = niz[najveci];
			niz[najveci] = temp;

			// Rekurzivno stvaranje heap-a za podstabla
			stvoriHeap(niz, duzina, najveci);
		}
	}
}
