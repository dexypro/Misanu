package bubbleSort;

public class BubbleSort {
	public static void main(String[] args) {
		int[] niz = { 64, 34, 25, 12, 22, 11, 90 };

		// Pozivamo funkciju za sortiranje niza
		bubbleSort(niz);

		System.out.println("Sortiran niz:");
		for (int element : niz) {
			System.out.print(element + " ");
		}
	}

	// Bubble Sort funkcija za sortiranje niza
	public static void bubbleSort(int[] niz) {
		int n = niz.length; // Dužina niza

		// Spoljašnja petlja prolazi kroz sve elemente niza
		for (int i = 0; i < n - 1; i++) {

			// Unutrašnja petlja prolazi kroz niz od 0 do n-i-1
			// Nakon svakog prolaska kroz petlju najveći element se "bubnji" do kraja
			for (int j = 0; j < n - i - 1; j++) {

				// Ako je trenutni element veći od sledećeg, zameni ih
				if (niz[j] > niz[j + 1]) {
					int temp = niz[j];
					niz[j] = niz[j + 1];
					niz[j + 1] = temp;
				}
			}
		}
	}
}
