package sortiranje;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Sortiranje {

	// Metoda za Bubble sortiranje
	public void bubbleSortiranje() throws NumberFormatException, IOException {
		int[] niz = new int[100];

		BufferedReader ulaz = new BufferedReader(new InputStreamReader(System.in));

		// Unos dimenzije niza
		System.out.println("Unesite broj elemenata n niza:");
		int n = Integer.parseInt(ulaz.readLine());

		// Unos elemenata niza
		System.out.println("Unesite elemente niza: ");
		for (int i = 0; i < n; i++) {
			System.out.print("niz[" + i + "] = ");
			niz[i] = Integer.parseInt(ulaz.readLine());
		}

		// Štampanje niza pre sortiranja
		System.out.println("Niz pre sortiranja: ");
		for (int i = 0; i < n; i++)
			System.out.print(niz[i] + " ");

		// Sortiranje elemenata niza
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (niz[i] > niz[j]) {
					// Zamena elemenata niza
					int pom = niz[i];
					niz[i] = niz[j];
					niz[j] = pom;
				}
			}
		}

		// Štampanje niza posle sortiranja
		System.out.println("\nNiz posle sortiranja: ");
		for (int i = 0; i < n; i++)
			System.out.print(niz[i] + " ");
	}

	// Metoda za Selection sortiranje
	public void selectionSortiranje() {

		int velicina, i, j, pom;
		int[] niz = new int[50];

		Scanner scan = new Scanner(System.in);
		System.out.print("Unesite broj elemenata n niza: ");
		velicina = scan.nextInt();

		System.out.println("Unesite elemente niza: ");
		for (i = 0; i < velicina; i++) {
			System.out.print("niz[" + i + "] = ");
			niz[i] = scan.nextInt();
		}

		System.out.print("Sortiranje niza metodom Selection..\n");
		for (i = 0; i < velicina; i++) {
			for (j = i + 1; j < velicina; j++) {
				if (niz[i] > niz[j]) {
					pom = niz[i];
					niz[i] = niz[j];
					niz[j] = pom;
				}
			}
		}

		System.out.print("\nNiz posle sortiranja: ");
		for (i = 0; i < velicina; i++) {
			System.out.print(niz[i] + "  ");
		}

	}

	// Metoda za Merge sortiranje
	public void mergeSortiranje() {

		Scanner sc = new Scanner(System.in);
		System.out.print("Unesite velicinu niza: ");
		int n = sc.nextInt();

		int[] niz = new int[n];

		System.out.println("Unesite elemente niza: ");
		for (int i = 0; i < n; i++) {
			System.out.print("niz[" + i + "] = ");
			niz[i] = sc.nextInt();
		}

		mergeSort(niz, 0, n - 1);

		System.out.println("Sortiran niz:");
		for (int i = 0; i < n; i++) {
			System.out.print(niz[i] + " ");
		}
	}

	public static void mergeSort(int[] niz, int start, int kraj) {
		if (start < kraj) {
			int sredina = (start + kraj) / 2;
			mergeSort(niz, start, sredina);
			mergeSort(niz, sredina + 1, kraj);
			merge(niz, start, sredina, kraj);
		}
	}

	public static void merge(int[] niz, int start, int sredina, int kraj) {
		int i, j, k;
		int n1 = sredina - start + 1;
		int n2 = kraj - sredina;

		int[] prviPodniz = new int[n1];
		int[] drugiPodniz = new int[n2];

		// Kopiramo podatke u privremene nizove
		for (i = 0; i < n1; i++) {
			prviPodniz[i] = niz[start + i];
		}
		for (j = 0; j < n2; j++) {
			drugiPodniz[j] = niz[sredina + 1 + j];
		}

		i = 0; // Početni indeks prvog podniza
		j = 0; // Početni indeks drugog podniza
		k = start; // Početni indeks spojenog podniza

		// Spajamo podnizove u sortirani niz
		while (i < n1 && j < n2) {
			if (prviPodniz[i] <= drugiPodniz[j]) {
				niz[k] = prviPodniz[i];
				i++;
			} else {
				niz[k] = drugiPodniz[j];
				j++;
			}
			k++;
		}

		// Dodajemo preostale elemente iz prvog podniza
		while (i < n1) {
			niz[k] = prviPodniz[i];
			i++;
			k++;
		}

		// Dodajemo preostale elemente iz drugog podniza
		while (j < n2) {
			niz[k] = drugiPodniz[j];
			j++;
			k++;
		}
	}

	// Metoda za Heap sortiranje
	public void heapSortiranje() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Unesite velicinu niza: ");
		int n = sc.nextInt();

		int[] niz = new int[n];
		System.out.println("Unesite elemente niza: ");
		for (int i = 0; i < n; i++) {
			System.out.print("niz[" + i + "] = ");
			niz[i] = sc.nextInt();
		}

		for (int i = n / 2 - 1; i >= 0; i--)
			heapify(niz, n, i);

		for (int i = n - 1; i > 0; i--) {
			int temp = niz[0];
			niz[0] = niz[i];
			niz[i] = temp;

			heapify(niz, i, 0);
		}

		System.out.println("Sortiran niz:");
		for (int i = 0; i < n; i++) {
			System.out.print(niz[i] + " ");
		}
	}

	private void heapify(int[] niz, int n, int i) {
		int najveci = i;
		int levoDete = 2 * i + 1;
		int desnoDete = 2 * i + 2;

		if (levoDete < n && niz[levoDete] > niz[najveci])
			najveci = levoDete;

		if (desnoDete < n && niz[desnoDete] > niz[najveci])
			najveci = desnoDete;

		if (najveci != i) {
			int temp = niz[i];
			niz[i] = niz[najveci];
			niz[najveci] = temp;

			heapify(niz, n, najveci);
		}
	}

	// Metoda za Insertion sortiranje
	public void insertionSortiranje() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Unesite velicinu niza: ");
		int n = sc.nextInt();

		int[] niz = new int[n];
		System.out.println("Unesite elemente niza: ");
		for (int i = 0; i < n; i++) {
			System.out.print("niz[" + i + "] = ");
			niz[i] = sc.nextInt();
		}

		for (int i = 1; i < n; ++i) {
			int kljuc = niz[i];
			int j = i - 1;

			while (j >= 0 && niz[j] > kljuc) {
				niz[j + 1] = niz[j];
				j = j - 1;
			}
			niz[j + 1] = kljuc;
		}

		System.out.println("Sortiran niz:");
		for (int i = 0; i < n; i++) {
			System.out.print(niz[i] + " ");
		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		Sortiranje sortiranje = new Sortiranje();

		System.out.println("********** Testiranje Bubble sortiranja **********");
		sortiranje.bubbleSortiranje();
		System.out.println("\n");

		System.out.println("********** Testiranje Selection sortiranja **********");
		sortiranje.selectionSortiranje();
		System.out.println("\n");

		System.out.println("********** Testiranje Merge sortiranja **********");
		sortiranje.mergeSortiranje();
		System.out.println("\n");

		System.out.println("********** Testiranje Heap sortiranja **********");
		sortiranje.heapSortiranje();
		System.out.println("\n");

		System.out.println("********** Testiranje Insertion sortiranja **********");
		sortiranje.insertionSortiranje();
	}

}