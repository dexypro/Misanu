package selectionSort;

public class SelectionSort {

	// Metoda za selekcioni sort
	public static void selectionSort(int[] arr) {
		int n = arr.length;

		// Prolazimo kroz sve elemente u nizu
		for (int i = 0; i < n - 1; i++) {
			// Pronalazimo indeks najmanjeg elementa u preostalom delu niza
			int minIndeks = i;
			for (int j = i + 1; j < n; j++) {
				if (arr[j] < arr[minIndeks]) {
					minIndeks = j;
				}
			}

			// Menjamo mesta trenutnom elementu i najmanjem elementu u preostalom delu niza
			if (minIndeks != i) {
				int temp = arr[minIndeks];
				arr[minIndeks] = arr[i];
				arr[i] = temp;
			}
		}
	}

	public static void main(String[] args) {
		int[] arr = { 64, 34, 25, 12, 22, 11, 90 };
		System.out.println("Nesortiran niz:");
		for (int e : arr) {
			System.out.print(e + " ");
		}
		System.out.println();

		selectionSort(arr);

		System.out.println("Sortiran niz:");
		for (int e : arr) {
			System.out.print(e + " ");
		}
		System.out.println();
	}
}
