package insertSort;

public class InsertionSort {

	public static void main(String[] args) {
		int[] niz = { 12, 11, 13, 5, 6, 7 };
		int duzina = niz.length;

		InsertionSort insertionSort = new InsertionSort();
		insertionSort.sortiraj(niz);

		System.out.println("Sortirani niz:");
		for (int i = 0; i < duzina; ++i) {
			System.out.print(niz[i] + " ");
		}
	}

	public void sortiraj(int niz[]) {
		int duzina = niz.length;

		// Prolazimo kroz niz počevši od drugog elementa (indeks 1)
		for (int i = 1; i < duzina; ++i) {
			// Izdvajamo trenutni element (ključ) sa kojim ćemo upoređivati prethodne
			// elemente
			int kljuc = niz[i];

			// Postavljamo indeks j na prethodni element u odnosu na trenutni
			int j = i - 1;

			// Pomeranje elemenata većih od ključa na jedno mesto udesno
			// Dok god je j veći ili jednak nuli i trenutni element veći od ključa
			while (j >= 0 && niz[j] > kljuc) {
				// Pomeramo trenutni element jedno mesto udesno
				niz[j + 1] = niz[j];
				// Smanjujemo indeks j za 1
				j = j - 1;
			}

			// Postavljamo ključ na odgovarajuću poziciju
			niz[j + 1] = kljuc;
		}
	}
}
