/**
 * 
 */
/**
 * @author bajov
 *
 */
module Biblioteka {
	requires java.sql;
	requires java.desktop;
}