/**
 * 
 */
/**
 * @author bajov
 *
 */
module Map {
}