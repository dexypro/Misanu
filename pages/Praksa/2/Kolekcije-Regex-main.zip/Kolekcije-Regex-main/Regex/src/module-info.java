/**
 * 
 */
/**
 * @author bajov
 *
 */
module Regex {
}