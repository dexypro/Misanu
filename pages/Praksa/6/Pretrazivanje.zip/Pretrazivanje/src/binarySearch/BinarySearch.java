package binarySearch;

public class BinarySearch {

	public static void main(String[] args) {
		int[] niz = { 2, 3, 4, 10, 15, 23, 25, 30, 34, 40, 45 };
		int trazeniBroj = 34;
		int indeks = binarySearch(niz, trazeniBroj);

		if (indeks == -1) {
			System.out.println("Broj " + trazeniBroj + " nije pronađen u nizu.");
		} else {
			System.out.println("Broj " + trazeniBroj + " je pronađen na indeksu " + indeks + ".");
		}
	}

	public static int binarySearch(int[] niz, int trazeniBroj) {
		int levo = 0;
		int desno = niz.length - 1;

		// Dok god je leva granica manja ili jednaka desnoj granici
		while (levo <= desno) {
			// Računamo srednji indeks
			int srednji = levo + (desno - levo) / 2;

			// Ako je srednji element jednak traženom broju
			if (niz[srednji] == trazeniBroj) {
				// Vraćamo indeks srednjeg elementa kao rezultat pretrage
				return srednji;
			}

			// Ako je srednji element manji od traženog broja
			if (niz[srednji] < trazeniBroj) {
				// Pomeramo levu granicu za jedno mesto desno od srednjeg indeksa
				levo = srednji + 1;
			} else {
				// Inače, pomeramo desnu granicu za jedno mesto levo od srednjeg indeksa
				desno = srednji - 1;
			}
		}

		// Ako nismo pronašli traženi broj u nizu, vraćamo -1
		return -1;
	}
}
