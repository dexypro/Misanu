package linearSearch;

public class LinearSearch {

	public static void main(String[] args) {
		int[] niz = { 10, 23, 15, 8, 4, 3, 25, 30, 34, 2, 7 };
		int trazeniBroj = 34;
		int indeks = linearSearch(niz, trazeniBroj);

		if (indeks == -1) {
			System.out.println("Broj " + trazeniBroj + " nije pronađen u nizu.");
		} else {
			System.out.println("Broj " + trazeniBroj + " je pronađen na indeksu " + indeks + ".");
		}
	}

	public static int linearSearch(int[] niz, int trazeniBroj) {
		int duzinaNiza = niz.length;

		// Prolazimo kroz sve elemente niza
		for (int i = 0; i < duzinaNiza; i++) {
			// Ako trenutni element odgovara traženom broju
			if (niz[i] == trazeniBroj) {
				// Vraćamo indeks trenutnog elementa kao rezultat pretrage
				return i;
			}
		}

		// Ako nismo pronašli traženi broj u nizu, vraćamo -1
		return -1;
	}
}
