package fibonacciSearch;

public class FibonacciSearch {

	public static void main(String[] args) {
		int[] niz = { 2, 3, 4, 10, 15, 23, 25, 30, 34, 40, 45 };
		int trazeniBroj = 34;
		int indeks = fibonacciSearch(niz, trazeniBroj);

		if (indeks == -1) {
			System.out.println("Broj " + trazeniBroj + " nije pronađen u nizu.");
		} else {
			System.out.println("Broj " + trazeniBroj + " je pronađen na indeksu " + indeks + ".");
		}
	}

	public static int fibonacciSearch(int[] niz, int trazeniBroj) {
		int duzina = niz.length;
		int fibMMm2 = 0; // (m-2)-ti Fibonacci broj
		int fibMMm1 = 1; // (m-1)-ti Fibonacci broj
		int fibM = fibMMm2 + fibMMm1; // m-ti Fibonacci broj

		// Pronalazimo najmanji Fibonacci broj veći ili jednak dužini niza
		while (fibM < duzina) {
			fibMMm2 = fibMMm1;
			fibMMm1 = fibM;
			fibM = fibMMm2 + fibMMm1;
		}

		int offset = -1;

		// Dok je fibM veći od 1
		while (fibM > 1) {
			int i = Math.min(offset + fibMMm2, duzina - 1);

			// Ako je traženi broj veći od elementa na indeksu i
			if (niz[i] < trazeniBroj) {
				fibM = fibMMm1;
				fibMMm1 = fibMMm2;
				fibMMm2 = fibM - fibMMm1;
				offset = i;
			} else if (niz[i] > trazeniBroj) {
				// Ako je traženi broj manji od elementa na indeksu i
				fibM = fibMMm2;
				fibMMm1 = fibMMm1 - fibMMm2;
				fibMMm2 = fibM - fibMMm1;
			} else {
				// Traženi broj je pronađen
				return i;
			}
		}

		// Ako je fibMMm1 jednak 1 i niz[offset+1] jednak traženom broju, vraćamo indeks
		if (fibMMm1 == 1 && niz[offset + 1] == trazeniBroj) {
			return offset + 1;
		}

		// Ako nismo pronašli traženi broj, vraćamo -1
		return -1;
	}
}
